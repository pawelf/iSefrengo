Pluginname:
---------------------------------------------------------------------------
Artikelsystem RSS v01.00.0x

Bechreibung:
---------------------------------------------------------------------------
Generiert eine oder mehrere XML-Datei(n) aus Artikeldaten des 
Artikelsystem-Plugin (und erzeugt einen Link innerhalb der SF-Seite 
zur XML-Datei).

Features:
---------------------------------------------------------------------------
- Frei definierbare XML-Ausgabe �ber Templates
- Update-Intervall und Anzahl der auszugebenen Eintr�ge einstellbar
- Ausgabe aller Elemente eines Artikels m�glich 
- Unterst�tzt das aus dem Artikelsystem-Plugin-Ausgabemodul bekannte
  Kategorie-Routing

Autor(en):
---------------------------------------------------------------------------
Alexander M. Korn (amk)

Lizenz:
---------------------------------------------------------------------------
GPL

Ben�tigte Sefrengo Version:
---------------------------------------------------------------------------
>= 01.03.01 (Sefrengo 1.4 beta 2)

Ben�tigte Artikelsystem-Plugin-Version:
---------------------------------------------------------------------------
>= 01.03.09

Installation:
---------------------------------------------------------------------------
Wechseln Sie in Ihrer Sefrengo Version in den Bereich "Design->Module". Am
unteren Ende des Bereichs befindet sich ein Uploadfeld. W�hlen Sie hier die
gew�nschte "*.cmsmod"- Datei aus. Mit einem Klick auf das Diskettensymbol 
wird das Modul in das CMS importiert. Das Modul ist nun innerhalb des CMS
nutzbar.

Legen Sie innerhalb ihres Sefrengo-Projektordners ein Verzeichnis "/rss" an.
Das Verzeichnis muss volle Schreib-/Leserechte besitzen (CHMOD 777).

Dokumentation:
---------------------------------------------------------------------------
keine vorhanden
